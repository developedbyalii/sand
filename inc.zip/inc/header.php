<header class="wrapper bg-soft-primary">
      <nav class="navbar navbar-expand-lg center-nav transparent navbar-light">
        <div class="container flex-lg-row flex-nowrap align-items-center">
          <!-- <div class="navbar-brand w-100">
            <a href="index.php">
              <img src="assets/img/logo-dark.png" srcset="./assets/img/logo-dark.png 2x" alt="" />
            </a>
          </div> -->
          <div class="navbar-collapse offcanvas offcanvas-nav offcanvas-start">
            <div class="offcanvas-header d-lg-none">
              <h3 class="text-white fs-30 mb-0">MAGAZINE</h3>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body ms-lg-auto d-flex flex-column h-100">
              <ul class="navbar-nav">
                   <li class="nav-item">
                  <a class="nav-link" href="#" >Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#" >Intelligencer</a>
                </li>
                <!--<li class="nav-item">-->
                <!--  <a class="nav-link" href="./feature.php" >Features</a>-->
                <!--</li>-->
                <!--<li class="nav-item">-->
                <!--  <a class="nav-link" href="javascript:;" >Support</a>-->
                <!--</li>-->
                <li class="nav-item">
                  <a class="nav-link" href="#" >Intelligencer</a>
                </li>

                
                <!--<li class="nav-item">-->
                <!--  <a class="nav-link" href="./free-trial.php" >Start Free Trial</a>-->
                <!--</li>-->
                <li class="nav-item">
                  <a class="nav-link" href="#" >The Strategist</a>
                </li>
                <li class="nav-item">
                <div class="navbar-brand w-100">
            <a href="index.php" class="nav-link p-3" >
              <img src="assets/img/logo-ne-1.png" height="100px" srcset="./assets/img/logo-ne-1.png " alt="" />
            </a>
          </div>
                </li>

                <li class="nav-item">
                  <a class="nav-link" href="#" >Curbed</a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" href="#" >Grube Street</a>
                </li>

                <li class="nav-item dropdown">
                 <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Magazine</a>
                 <ul class="dropdown-menu">
                   <li class="nav-item"><a class="dropdown-item" href="#">Enterprise</a></li>
                   <li class="nav-item"><a class="dropdown-item" href="#">Medical</a></li>
                   <li class="nav-item"><a class="dropdown-item" href="#">Insurance</a></li>
                   <li class="nav-item"><a class="dropdown-item" href="#">Real State</a></li>
                 </ul>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#" >Subcribe</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#" >Login</a>
                </li>
              </ul>
              <!-- /.navbar-nav -->
              <div class="offcanvas-footer d-lg-none">
                <div>
                  <a href="cdn-cgi/l/email-protection.html#05636c7776712b69647671456068646c692b666a68" class="link-inverse"><span class="__cf_email__" data-cfemail="70191e161f30151d11191c5e131f1d">[email&#160;protected]</span></a>
                  <br /> 00 (123) 456 78 90 <br />
                  <nav class="nav social social-white mt-4">
                    <a href="#"><i class="uil uil-twitter"></i></a>
                    <a href="#"><i class="uil uil-facebook-f"></i></a>
                    <a href="#"><i class="uil uil-dribbble"></i></a>
                    <a href="#"><i class="uil uil-instagram"></i></a>
                    <a href="#"><i class="uil uil-youtube"></i></a>
                  </nav>
                  <!-- /.social -->
                </div>
              </div>
              <!-- /.offcanvas-footer -->
            </div>
            <!-- /.offcanvas-body -->
          </div>
          <!-- /.navbar-collapse -->


          <div class="navbar-other ms-auto">
              <ul class="navbar-nav flex-row align-items-center">
                <li class="nav-item d-lg-none">
                  <button class="hamburger offcanvas-nav-btn"><span></span></button>
                </li>
              </ul>
              <!-- /.navbar-nav -->
            </div>

          
          <!-- /.navbar-other -->
        </div>
        <!-- /.container -->
      </nav>
      <!-- /.navbar -->
      
    </header>