<script src="assets/js/plugins.js"></script>
  <script src="assets/js/theme.js"></script>
<script src="https://kit.fontawesome.com/5c90fb4b02.js" crossorigin="anonymous"></script>
