<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="An impressive and flawless site template that includes various UI elements and countless features, attractive ready-made blocks and rich pages, basically everything you need to create a unique and professional website.">
  <meta name="keywords" content="bootstrap 5, business, corporate, creative, gulp, marketing, minimal, modern, multipurpose, one page, responsive, saas, sass, seo, startup, html5 template, site template">
  <meta name="author" content="elemis">
  <title>PDF EDITOR</title>
  <?php include('inc/styles.php') ?>
</head>
<style>
  .swiper-button {
    display: none;
  }

  .form-group.files {
    outline: 2px dashed #92b0b3;
    outline-offset: -10px;
    -webkit-transition: outline-offset .15s ease-in-out, background-color .15s linear;
    transition: outline-offset .15s ease-in-out, background-color .15s linear;
    padding: 100px;
    text-align: center !important;
    margin: 0;
    width: 100% !important;
  }

  .files {
    position: relative
  }

  .files:after {
    pointer-events: none;
    position: absolute;
    top: 60px;
    left: 0;
    width: 50px;
    right: 0;
    height: 56px;
    content: "";
    background-image: url(https://image.flaticon.com/icons/png/128/109/109612.png);
    display: block;
    margin: 0 auto;
    background-size: 100%;
    background-repeat: no-repeat;
  }

  .color input {
    background-color: #f1f1f1;
  }


  .problem-solving-section h4 {
    font-size: 25px;
    font-weight: 600;
    text-align: center;
  }

  .problem-solving-section li {
    list-style: none;
    font-size: 18px;
    font-weight: 400
  }

  .problem-solving-section li a {
    color: #60697b;
  }

  .problem-solving-section ul {
    font-size: 20px;
    font-weight: 500;
  }

  .problem-solving-section li i {
    font-size: 15px;
    color: #60697b;
    padding-right: 10px;
  }
</style>

<body>
  <div class="content-wrapper">
    <?php include('inc/header.php') ?>
    <!-- /header -->

<!-- charles lenox work -->

<div class="content-wrapper">
    <header class="wrapper bg-soft-primary">
  
      <!-- /.navbar -->
      <div class="offcanvas offcanvas-end text-inverse" id="offcanvas-info" data-bs-scroll="true">
        <div class="offcanvas-header">
          <h3 class="text-white fs-30 mb-0">Sandbox</h3>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body pb-6">
          <div class="widget mb-8">
            <p>Sandbox is a multipurpose HTML5 template with various layouts which will be a great solution for your business.</p>
          </div>
          <!-- /.widget -->
          <div class="widget mb-8">
            <h4 class="widget-title text-white mb-3">Contact Info</h4>
            <address> Moonshine St. 14/05 <br> Light City, London </address>
            <a href="mailto:first.last@email.com">info@email.com</a><br> 00 (123) 456 78 90
          </div>
          <!-- /.widget -->
          <div class="widget mb-8">
            <h4 class="widget-title text-white mb-3">Learn More</h4>
            <ul class="list-unstyled">
              <li><a href="#">Our Story</a></li>
              <li><a href="#">Terms of Use</a></li>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="#">Contact Us</a></li>
            </ul>
          </div>
          <!-- /.widget -->
          <div class="widget">
            <h4 class="widget-title text-white mb-3">Follow Us</h4>
            <nav class="nav social social-white">
              <a href="#"><i class="uil uil-twitter"></i></a>
              <a href="#"><i class="uil uil-facebook-f"></i></a>
              <a href="#"><i class="uil uil-dribbble"></i></a>
              <a href="#"><i class="uil uil-instagram"></i></a>
              <a href="#"><i class="uil uil-youtube"></i></a>
            </nav>
            <!-- /.social -->
          </div>
          <!-- /.widget -->
        </div>
        <!-- /.offcanvas-body -->
      </div>
      <!-- /.offcanvas -->
      <div class="offcanvas offcanvas-top bg-light" id="offcanvas-search" data-bs-scroll="true">
        <div class="container d-flex flex-row py-6">
          <form class="search-form w-100">
            <input id="search-form" type="text" class="form-control" placeholder="Type keyword and hit enter">
          </form>
          <!-- /.search-form -->
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <!-- /.container -->
      </div>
      <!-- /.offcanvas -->
    </header>
    <!-- /header -->
    <section class="wrapper bg-dark">
      <div class="swiper-container swiper-hero dots-over swiper-container-0" data-margin="0" data-autoplay="true" data-autoplaytime="7000" data-nav="true" data-dots="true" data-items="1">
        <div class="swiper swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden">
          <div class="swiper-wrapper" id="swiper-wrapper-57203256069710910d" aria-live="off" style="cursor: grab; transform: translate3d(0px, 0px, 0px); transition-duration: 500ms;">
            <div class="swiper-slide bg-overlay bg-overlay-400 bg-dark bg-image swiper-slide-active" data-image-src="./assets/img/charles-img-3.jpg" role="group" aria-label="1 / 3" style="background-image: url(&quot;./assets/img/photos/bg7.jpg&quot;); width: 1663px;">
              <div class="container h-100">
                <div class="row h-100">
                  <div class="col-md-10 offset-md-1 col-lg-7 offset-lg-0 col-xl-6 col-xxl-5 text-center text-lg-start justify-content-center align-self-center align-items-start">
                    <h2 class="display-1 fs-56 mb-4 text-white animate__animated animate__slideInDown animate__delay-1s">We bring solutions to make life easier.</h2>
                    <p class="lead fs-23 lh-sm mb-7 text-white animate__animated animate__slideInRight animate__delay-2s">We are a creative company that focuses on long term relationships with customers.</p>
                    <div class="animate__animated animate__slideInUp animate__delay-3s"><a href="#" class="btn btn-lg btn-outline-white rounded-pill">Read More</a></div>
                  </div>
                  <!--/column -->
                </div>
                <!--/.row -->
              </div>
              <!--/.container -->
            </div>
            <!--/.swiper-slide -->
           
            <!--/.swiper-slide -->
            <div class="swiper-slide bg-overlay bg-overlay-400 bg-dark bg-image" data-image-src="./assets/img/charles-img-2.jpg" role="group" aria-label="3 / 3" style="background-image: url(&quot;./assets/img/photos/bg9.jpg&quot;); width: 1663px;">
              <div class="container h-100">
                <div class="row h-100">
                  <div class="col-md-10 offset-md-1 col-lg-7 offset-lg-5 col-xl-6 offset-xl-6 col-xxl-5 offset-xxl-6 text-center text-lg-start justify-content-center align-self-center align-items-start">
                    <h2 class="display-1 fs-56 mb-4 text-white animate__animated animate__slideInDown animate__delay-1s">Just sit and relax.</h2>
                    <p class="lead fs-23 lh-sm mb-7 text-white animate__animated animate__slideInRight animate__delay-2s">We make sure your spending is stress free so that you can have the perfect control.</p>
                    <div class="animate__animated animate__slideInUp animate__delay-3s"><a href="#" class="btn btn-lg btn-outline-white rounded-pill">Contact Us</a></div>
                  </div>
                  <!--/column -->
                </div>
                <!--/.row -->
              </div>
              <!--/.container -->
            </div>
            <!--/.swiper-slide -->
          </div>
          <!--/.swiper-wrapper -->
        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
        <!-- /.swiper -->
      <div class="swiper-controls"><div class="swiper-navigation"><div class="swiper-button swiper-button-prev swiper-button-disabled" tabindex="-1" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-57203256069710910d" aria-disabled="true"></div><div class="swiper-button swiper-button-next" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-57203256069710910d" aria-disabled="false"></div></div><div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal"><span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button" aria-label="Go to slide 1" aria-current="true"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 2"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 3"></span></div></div></div>
      <!-- /.swiper-container -->
    </section>


    <section class="nav-topic">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="magazine-header">
              <ul>
                <li><a href="#javascript:;">TV</a></li>
                <li><a href="#javascript:;">RECAPS</a></li>
                <li><a href="#javascript:;">MOVIES</a></li>
                <li><a href="#javascript:;">COMEDY</a></li>
                <li><a href="#javascript:;">MUSIC</a></li>
                <li><a href="#javascript:;">BOOKS</a></li>
                <li><a href="#javascript:;">PODCASTS</a></li>
                <li><a href="#javascript:;">STREAMING</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>



  <section class="wrapper bg-light">
      <div class="container py-14 py-md-16">
        <div class="row gx-lg-8 gx-xl-12">
          <div class="col-lg-8 order-lg-2">
            <div class="blog classic-view">
             
              <!-- /.post -->
              <article class="post">
                <div class="card">
                  <div class="post-slider card-img-top">
                    <div class="swiper-container dots-over swiper-container-0" data-margin="5" data-nav="true" data-dots="true">
                      <div class="swiper swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden">
                        <div class="swiper-wrapper" id="swiper-wrapper-787c80e487827f4e" aria-live="off" style="cursor: grab; transform: translate3d(0px, 0px, 0px);">
                          <div class="swiper-slide swiper-slide-active" role="group" aria-label="1 / 2" style="width: 837px; margin-right: 5px;"><img src="./assets/img/photos/b2.jpg" alt=""></div>
                          <div class="swiper-slide swiper-slide-next" role="group" aria-label="2 / 2" style="width: 837px; margin-right: 5px;"><img src="./assets/img/photos/b3.jpg" alt=""></div>
                        </div>
                        <!--/.swiper-wrapper -->
                      <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                      <!-- /.swiper -->
                    <div class="swiper-controls"><div class="swiper-navigation"><div class="swiper-button swiper-button-prev swiper-button-disabled" tabindex="-1" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-787c80e487827f4e" aria-disabled="true"></div><div class="swiper-button swiper-button-next" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-787c80e487827f4e" aria-disabled="false"></div></div><div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal"><span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button" aria-label="Go to slide 1" aria-current="true"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 2"></span></div></div></div>
                    <!-- /.swiper-container -->
                  </div>
                  <!-- /.post-slider -->
                  <div class="card-body">
                    <div class="post-header">
                      <div class="post-category text-line">
                        <a href="#" class="hover" rel="category">Ideas</a>
                      </div>
                      <!-- /.post-category -->
                      <h2 class="post-title mt-1 mb-0"><a class="link-dark" href="./blog-post.php">Fringilla Ligula Pharetra Amet</a></h2>
                    </div>
                    <!-- /.post-header -->
                    <div class="post-content">
                      <p>Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Nullam quis risus eget urna mollis ornare vel. Nulla vitae elit libero, a pharetra augue. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh. Cras mattis consectetur purus.</p>
                    </div>
                    <!-- /.post-content -->
                  </div>
                  <!--/.card-body -->
                  <div class="card-footer">
                    <ul class="post-meta d-flex mb-0">
                      <li class="post-date"><i class="uil uil-calendar-alt"></i><span>25 Jun 2022</span></li>
                      <li class="post-author"><a href="#"><i class="uil uil-user"></i><span>By Sandbox</span></a></li>
                      <li class="post-comments"><a href="#"><i class="uil uil-comment"></i>5<span> Comments</span></a></li>
                      <li class="post-likes ms-auto"><a href="#"><i class="uil uil-heart-alt"></i>4</a></li>
                    </ul>
                    <!-- /.post-meta -->
                  </div>
                  <!-- /.card-footer -->
                </div>
                <!-- /.card -->
              </article>
              <!-- /.post -->
            
            </div>
            <!-- /.blog -->
            <div class="blog grid grid-view">
              <div class="row isotope gx-md-8 gy-8 mb-8" style="position: relative; height: 1262.19px;">
                <article class="item post col-md-6" style="position: absolute; left: 0%; top: 0px;">
                  <div class="card">
                    <figure class="card-img-top overlay overlay-1 hover-scale"><a href="#"> <img src="./assets/img/photos/b4.jpg" alt=""><span class="bg"></span></a>
                      <figcaption>
                        <h5 class="from-top mb-0">Read More</h5>
                      </figcaption>
                    </figure>
                    <div class="card-body">
                      <div class="post-header">
                        <div class="post-category text-line">
                          <a href="#" class="hover" rel="category">Coding</a>
                        </div>
                        <!-- /.post-category -->
                        <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="./blog-post.php">Ligula tristique quis risus</a></h2>
                      </div>
                      <!-- /.post-header -->
                      <div class="post-content">
                        <p>Mauris convallis non ligula non interdum. Gravida vulputate convallis tempus vestibulum cras imperdiet nun eu dolor. Aenean lacinia bibendum nulla sed.</p>
                      </div>
                      <!-- /.post-content -->
                    </div>
                    <!--/.card-body -->
                    <div class="card-footer">
                      <ul class="post-meta d-flex mb-0">
                        <li class="post-date"><i class="uil uil-calendar-alt"></i><span>14 Apr 2022</span></li>
                        <li class="post-comments"><a href="#"><i class="uil uil-comment"></i>4</a></li>
                        <li class="post-likes ms-auto"><a href="#"><i class="uil uil-heart-alt"></i>5</a></li>
                      </ul>
                      <!-- /.post-meta -->
                    </div>
                    <!-- /.card-footer -->
                  </div>
                  <!-- /.card -->
                </article>
                <!-- /.post -->
                <article class="item post col-md-6" style="position: absolute; left: 50.0196%; top: 0px;">
                  <div class="card">
                    <figure class="card-img-top overlay overlay-1 hover-scale"><a href="#"> <img src="./assets/img/photos/b5.jpg" alt=""><span class="bg"></span></a>
                      <figcaption>
                        <h5 class="from-top mb-0">Read More</h5>
                      </figcaption>
                    </figure>
                    <div class="card-body">
                      <div class="post-header">
                        <div class="post-category text-line">
                          <a href="#" class="hover" rel="category">Workspace</a>
                        </div>
                        <!-- /.post-category -->
                        <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="./blog-post.php">Nullam id dolor elit id nibh</a></h2>
                      </div>
                      <!-- /.post-header -->
                      <div class="post-content">
                        <p>Mauris convallis non ligula non interdum. Gravida vulputate convallis tempus vestibulum cras imperdiet nun eu dolor. Aenean lacinia bibendum nulla sed.</p>
                      </div>
                      <!-- /.post-content -->
                    </div>
                    <!--/.card-body -->
                    <div class="card-footer">
                      <ul class="post-meta d-flex mb-0">
                        <li class="post-date"><i class="uil uil-calendar-alt"></i><span>29 Mar 2022</span></li>
                        <li class="post-comments"><a href="#"><i class="uil uil-comment"></i>3</a></li>
                        <li class="post-likes ms-auto"><a href="#"><i class="uil uil-heart-alt"></i>3</a></li>
                      </ul>
                      <!-- /.post-meta -->
                    </div>
                    <!-- /.card-footer -->
                  </div>
                  <!-- /.card -->
                </article>
                <!-- /.post -->
                <article class="item post col-md-6" style="position: absolute; left: 0%; top: 631.094px;">
                  <div class="card">
                    <figure class="card-img-top overlay overlay-1 hover-scale"><a href="#"> <img src="./assets/img/photos/b6.jpg" alt=""><span class="bg"></span></a>
                      <figcaption>
                        <h5 class="from-top mb-0">Read More</h5>
                      </figcaption>
                    </figure>
                    <div class="card-body">
                      <div class="post-header">
                        <div class="post-category text-line">
                          <a href="#" class="hover" rel="category">Meeting</a>
                        </div>
                        <!-- /.post-category -->
                        <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="./blog-post.php">Ultricies fusce porta elit</a></h2>
                      </div>
                      <!-- /.post-header -->
                      <div class="post-content">
                        <p>Mauris convallis non ligula non interdum. Gravida vulputate convallis tempus vestibulum cras imperdiet nun eu dolor. Aenean lacinia bibendum nulla sed.</p>
                      </div>
                      <!-- /.post-content -->
                    </div>
                    <!--/.card-body -->
                    <div class="card-footer">
                      <ul class="post-meta d-flex mb-0">
                        <li class="post-date"><i class="uil uil-calendar-alt"></i><span>26 Feb 2022</span></li>
                        <li class="post-comments"><a href="#"><i class="uil uil-comment"></i>6</a></li>
                        <li class="post-likes ms-auto"><a href="#"><i class="uil uil-heart-alt"></i>3</a></li>
                      </ul>
                      <!-- /.post-meta -->
                    </div>
                    <!-- /.card-footer -->
                  </div>
                  <!-- /.card -->
                </article>
                <!-- /.post -->
                <article class="item post col-md-6" style="position: absolute; left: 50.0196%; top: 631.094px;">
                  <div class="card">
                    <figure class="card-img-top overlay overlay-1 hover-scale"><a href="#"> <img src="./assets/img/photos/b7.jpg" alt=""><span class="bg"></span></a>
                      <figcaption>
                        <h5 class="from-top mb-0">Read More</h5>
                      </figcaption>
                    </figure>
                    <div class="card-body">
                      <div class="post-header">
                        <div class="post-category text-line">
                          <a href="#" class="hover" rel="category">Business Tips</a>
                        </div>
                        <!-- /.post-category -->
                        <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="./blog-post.php">Morbi leo risus porta eget</a></h2>
                      </div>
                      <div class="post-content">
                        <p>Mauris convallis non ligula non interdum. Gravida vulputate convallis tempus vestibulum cras imperdiet nun eu dolor. Aenean lacinia bibendum nulla sed.</p>
                      </div>
                      <!-- /.post-content -->
                    </div>
                    <!--/.card-body -->
                    <div class="card-footer">
                      <ul class="post-meta d-flex mb-0">
                        <li class="post-date"><i class="uil uil-calendar-alt"></i><span>7 Jan 2022</span></li>
                        <li class="post-comments"><a href="#"><i class="uil uil-comment"></i>2</a></li>
                        <li class="post-likes ms-auto"><a href="#"><i class="uil uil-heart-alt"></i>5</a></li>
                      </ul>
                      <!-- /.post-meta -->
                    </div>
                    <!-- /.card-footer -->
                  </div>
                  <!-- /.card -->
                </article>
                <!-- /.post -->
              </div>
              <!-- /.row -->
            </div>
            <!-- /.blog -->
            <!-- <nav class="d-flex" aria-label="pagination">
              <ul class="pagination">
                <li class="page-item disabled">
                  <a class="page-link" href="#" aria-label="Previous">
                    <span aria-hidden="true"><i class="uil uil-arrow-left"></i></span>
                  </a>
                </li>
                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item">
                  <a class="page-link" href="#" aria-label="Next">
                    <span aria-hidden="true"><i class="uil uil-arrow-right"></i></span>
                  </a>
                </li>
              </ul>
              
            </nav> -->
            <!-- /nav -->
          </div>
          <!-- /column -->
          <aside class="col-lg-4 sidebar mt-8 mt-lg-6">
            <div class="widget">
              <form class="search-form">
                <div class="form-floating mb-0">
                  <input id="search-form" type="text" class="form-control" placeholder="Search">
                  <label for="search-form">Search</label>
                </div>
              </form>
              <!-- /.search-form -->
            </div>
            <!-- /.widget -->
            <div class="widget">
              <h4 class="widget-title mb-3">About Us</h4>
              <p>Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum. Nulla vitae elit libero, a pharetra augue. Donec id elit non mi porta gravida at eget metus.</p>
              <nav class="nav social">
                <a href="#"><i class="uil uil-twitter"></i></a>
                <a href="#"><i class="uil uil-facebook-f"></i></a>
                <a href="#"><i class="uil uil-dribbble"></i></a>
                <a href="#"><i class="uil uil-instagram"></i></a>
                <a href="#"><i class="uil uil-youtube"></i></a>
              </nav>
              <!-- /.social -->
            </div>



            <div class="widget">
              <h4 class="widget-title mb-3">Categories</h4>
              <ul class="unordered-list bullet-primary text-reset">
                <li><a href="#">TV (21)</a></li>
                <li><a href="#">MOVIES (19)</a></li>
                <li><a href="#">COMEDY (16)</a></li>
                <li><a href="#">MUSIC (7)</a></li>
                <li><a href="#">TV RECAPS (12)</a></li>
                <li><a href="#">STREAMLINER (14)</a></li>
                <li><a href="#">BOOKS (14)</a></li>
                <li><a href="#">THEATER (14)</a></li>
                <li><a href="#">ART (14)</a></li>
                <li><a href="#">THE GOLD RUSH (14)</a></li>
                <li><a href="#">PODCASTS (14)</a></li>
                <li><a href="#">VIDEOS (14)</a></li>
              </ul>
            </div>

            <!-- /.widget -->
            <div class="widget">
              <h4 class="widget-title mb-3">Popular Posts</h4>
              <ul class="image-list">
                <li>
                  <figure class="rounded"><a href="./blog-post.php"><img src="./assets/img/photos/a1.jpg" alt=""></a></figure>
                  <div class="post-content">
                    <h6 class="mb-2"> <a class="link-dark" href="./blog-post.php">Magna Mollis Ultricies</a> </h6>
                    <ul class="post-meta">
                      <li class="post-date"><i class="uil uil-calendar-alt"></i><span>26 Mar 2022</span></li>
                      <li class="post-comments"><a href="#"><i class="uil uil-comment"></i>3</a></li>
                    </ul>
                    <!-- /.post-meta -->
                  </div>
                </li>
                <li>
                  <figure class="rounded"> <a href="./blog-post.php"><img src="./assets/img/photos/a2.jpg" alt=""></a></figure>
                  <div class="post-content">
                    <h6 class="mb-2"> <a class="link-dark" href="./blog-post.php">Ornare Nullam Risus</a> </h6>
                    <ul class="post-meta">
                      <li class="post-date"><i class="uil uil-calendar-alt"></i><span>16 Feb 2022</span></li>
                      <li class="post-comments"><a href="#"><i class="uil uil-comment"></i>6</a></li>
                    </ul>
                    <!-- /.post-meta -->
                  </div>
                </li>
                <li>
                  <figure class="rounded"><a href="./blog-post.php"><img src="./assets/img/photos/a3.jpg" alt=""></a></figure>
                  <div class="post-content">
                    <h6 class="mb-2"> <a class="link-dark" href="./blog-post.php">Euismod Nullam Fusce</a> </h6>
                    <ul class="post-meta">
                      <li class="post-date"><i class="uil uil-calendar-alt"></i><span>8 Jan 2022</span></li>
                      <li class="post-comments"><a href="#"><i class="uil uil-comment"></i>5</a></li>
                    </ul>
                    <!-- /.post-meta -->
                  </div>
                </li>
              </ul>
              <!-- /.image-list -->
            </div>



      

            <!-- /.widget -->
            
            <!-- /.widget -->
            <div class="widget">
              <h4 class="widget-title mb-3">Tags</h4>
              <ul class="list-unstyled tag-list">
                <li><a href="#" class="btn btn-soft-ash btn-sm rounded-pill">Still Life</a></li>
                <li><a href="#" class="btn btn-soft-ash btn-sm rounded-pill">Urban</a></li>
                <li><a href="#" class="btn btn-soft-ash btn-sm rounded-pill">Nature</a></li>
                <li><a href="#" class="btn btn-soft-ash btn-sm rounded-pill">Landscape</a></li>
                <li><a href="#" class="btn btn-soft-ash btn-sm rounded-pill">Macro</a></li>
                <li><a href="#" class="btn btn-soft-ash btn-sm rounded-pill">Fun</a></li>
                <li><a href="#" class="btn btn-soft-ash btn-sm rounded-pill">Workshop</a></li>
                <li><a href="#" class="btn btn-soft-ash btn-sm rounded-pill">Photography</a></li>
              </ul>
            </div>
            <!-- /.widget -->
            <div class="widget">
              <h4 class="widget-title mb-3">Archive</h4>
              <ul class="unordered-list bullet-primary text-reset">
                <li><a href="#">February 2019</a></li>
                <li><a href="#">January 2019</a></li>
                <li><a href="#">December 2018</a></li>
                <li><a href="#">November 2018</a></li>
                <li><a href="#">October 2018</a></li>
              </ul>
            </div>
            <!-- /.widget -->
          </aside>
          <!-- /column .sidebar -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>



    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

        <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>

          <div class="reality-begins">
              <span>WOMEN!<a href="#javascript:;"> 11:25 A.M</a></span>
              <p><a href="#javascript:;">The Vienna Puzzle 22-</a> Down, Four Letters: Barb’s BFF played by Kristen Wigg.</p>
          </div>
          </div>
          <div class="col-md-6 mx-auto">
            <div class="popular-season">
              <h2>MOST POPULAR</h2>
              <ul>
                <li><a href="#javascript:;">What’s the Best Way to Watch Randomized Heist Series Kaleidoscope?</a></li>
                <li><a href="#javascript:;">What’s Going on With Wednesday Season Two?</a></li>
                <li><a href="#javascript:;">Theophilus London Reported Missing Since October</a></li>
                <li><a href="#javascript:;">Emma Thompson Says Colin Farrell ‘Broke’ Her Heart in The Banshees of Inisherin</a></li>
                <li><a href="#javascript:;">Robert Plant on the Finest and Most Questionable Music of His Career</a></li>
              </ul>
            </div>

            <h2 class="profit-head">Recaps</h2>

            <div class="throwback-hope">
              <div class="row">
                <div class="col-md-4">
                  <div class="recaps">
                  <img src="./assets/img/photos/ul-1.jpg" alt="">
                  </div>
                </div>
                <div class="col-md-8">
                   <div class="vulture-list">
                    <span><a href="#javascript:;">GOSSIP GIRL</a>  (S2/E7)</span>
                    <p><a href="#javascript:;">Throwback Thursday</a> It’s a trip back to 2009, and Georgina Sparks is at the wheel.</p>
                  </div>
                </div>
              </div>
            </div>

            <div class="throwback-hope">
              <div class="row">
                <div class="col-md-4">
                  <div class="recaps">
                  <img src="./assets/img/photos/ul-2.jpg" alt="">
                  </div>
                </div>
                <div class="col-md-8">
                   <div class="vulture-list">
                    <span><a href="#javascript:;">GOSSIP GIRL</a>  (S2/E7)</span>
                    <p><a href="#javascript:;">Throwback Thursday</a> It’s a trip back to 2009, and Georgina Sparks is at the wheel.</p>
                  </div>
                </div>
              </div>
            </div>

            <div class="throwback-hope">
              <div class="row">
                <div class="col-md-4">
                  <div class="recaps">
                  <img src="./assets/img/photos/ul-3.jpg" alt="">
                  </div>
                </div>
                <div class="col-md-8">
                   <div class="vulture-list">
                    <span><a href="#javascript:;">GOSSIP GIRL</a>  (S2/E7)</span>
                    <p><a href="#javascript:;">Throwback Thursday</a> It’s a trip back to 2009, and Georgina Sparks is at the wheel.</p>
                  </div>
                </div>
              </div>
            </div>

            <div class="throwback-hope">
              <div class="row">
                <div class="col-md-4">
                  <div class="recaps">
                  <img src="./assets/img/photos/ul-4.jpg" alt="">
                  </div>
                </div>
                <div class="col-md-8">
                   <div class="vulture-list">
                    <span><a href="#javascript:;">GOSSIP GIRL</a>  (S2/E7)</span>
                    <p><a href="#javascript:;">Throwback Thursday</a> It’s a trip back to 2009, and Georgina Sparks is at the wheel.</p>
                  </div>
                </div>
              </div>
            </div>

            <div class="throwback-hope">
              <div class="row">
                <div class="col-md-4">
                  <div class="recaps">
                  <img src="./assets/img/photos/ul-5.jpg" alt="">
                  </div>
                </div>
                <div class="col-md-8">
                   <div class="vulture-list">
                    <span><a href="#javascript:;">GOSSIP GIRL</a>  (S2/E7)</span>
                    <p><a href="#javascript:;">Throwback Thursday</a> It’s a trip back to 2009, and Georgina Sparks is at the wheel.</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- features -->
<div class="features">
  <h1>Features</h1>
            <div class="blog grid grid-view">
              <div class="row isotope gx-md-8 gy-8 mb-8" style="position: relative; height: 1262.19px;">
                <article class="item post col-md-6" style="position: absolute; left: 0%; top: 0px;">
                  <div class="card">
                    <figure class="card-img-top overlay overlay-1 hover-scale"><a href="#"> <img src="./assets/img/photos/features-1.jpg" alt=""><span class="bg"></span></a>
                      <figcaption>
                        <h5 class="from-top mb-0">Read More</h5>
                      </figcaption>
                    </figure>
                    <div class="card-body">
                      <div class="post-header">
                        <div class="post-category text-line">
                          <a href="#" class="hover" rel="category">2023 PREVIEW</a>
                        </div>
                        <!-- /.post-category -->
                        <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="./blog-post.php">28 Albums We Can’t Wait to Hear in 2023</a></h2>
                      </div>
                      <!-- /.post-header -->
                      <div class="post-content">
                        <p>Shania and Cardi and (maybe?) Frank. <br> BY CAT CARDENAS</p>
                      </div>
                      <!-- /.post-content -->
                    </div>
                    <!--/.card-body -->
                    <!-- /.card-footer -->
                  </div>
                  <!-- /.card -->
                </article>
                <!-- /.post -->
                <article class="item post col-md-6" style="position: absolute; left: 50.0196%; top: 0px;">
                  <div class="card">
                    <figure class="card-img-top overlay overlay-1 hover-scale"><a href="#"> <img src="./assets/img/photos/features-2.jpg" alt=""><span class="bg"></span></a>
                      <figcaption>
                        <h5 class="from-top mb-0">Read More</h5>
                      </figcaption>
                    </figure>
                    <div class="card-body">
                      <div class="post-header">
                        <div class="post-category text-line">
                          <a href="#" class="hover" rel="category">2023 PREVIEW</a>
                        </div>
                        <!-- /.post-category -->
                        <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="./blog-post.php">31 Books We Can’t Wait to Read in 2023</a></h2>
                      </div>
                      <!-- /.post-header -->
                      <div class="post-content">
                        <p>No matter what else happens in 2023, we can guarantee that the books will be good.</p>
                      </div>
                      <!-- /.post-content -->
                    </div>
                    <!--/.card-body -->
                   
                    <!-- /.card-footer -->
                  </div>
                  <!-- /.card -->
                </article>
                <!-- /.post -->
                <article class="item post col-md-6" style="position: absolute; left: 0%; top: 631.094px;">
                  <div class="card">
                    <figure class="card-img-top overlay overlay-1 hover-scale"><a href="#"> <img src="./assets/img/photos/features-3.jpg" alt=""><span class="bg"></span></a>
                      <figcaption>
                        <h5 class="from-top mb-0">Read More</h5>
                      </figcaption>
                    </figure>
                    <div class="card-body">
                      <div class="post-header">
                        <div class="post-category text-line">
                          <a href="#" class="hover" rel="category">2023 PREVIEW</a>
                        </div>
                        <!-- /.post-category -->
                        <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="./blog-post.php">Glass Onion Isn’t Trying to Trick You</a></h2>
                      </div>
                      <!-- /.post-header -->
                      <div class="post-content">
                        <p>According to director Rian Johnson, every twist in his sequel is right in front of your face. <br> BY ALISON WILLMORE</p>
                      </div>
                      <!-- /.post-content -->
                    </div>
                    <!--/.card-body -->
                  
                    <!-- /.card-footer -->
                  </div>
                  <!-- /.card -->
                </article>
                <!-- /.post -->
                <article class="item post col-md-6" style="position: absolute; left: 50.0196%; top: 631.094px;">
                  <div class="card">
                    <figure class="card-img-top overlay overlay-1 hover-scale"><a href="#"> <img src="./assets/img/photos/features-4.jpg" alt=""><span class="bg"></span></a>
                      <figcaption>
                        <h5 class="from-top mb-0">Read More</h5>
                      </figcaption>
                    </figure>
                    <div class="card-body">
                      <div class="post-header">
                        <div class="post-category text-line">
                          <a href="#" class="hover" rel="category">2023 PREVIEW</a>
                        </div>
                        <!-- /.post-category -->
                        <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="./blog-post.php">36 TV Shows We Can’t Wait to See in 2023</a></h2>
                      </div>
                      <div class="post-content">
                        <p>Let’s revel in anticipation of the televisual pleasures the new year will bring. <br> BY VULTURE EDITORS</p>
                      </div>
                      <!-- /.post-content -->
                    </div>
                    <!--/.card-body -->
                 
                    <!-- /.card-footer -->
                  </div>
                  <!-- /.card -->
                </article>
                <!-- /.post -->
              </div>
              <!-- /.row -->
            </div>
            </div>
<!-- features end -->

          </div>
        </div>
      </div>
    </section>


  </div>

  <!-- /.content-wrapper -->
  <?php include('inc/footer.php') ?>
  <div class="progress-wrap">
    <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
      <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
    </svg>
  </div>
  <?php include('inc/scripts.php') ?>
  
</body>

</html>